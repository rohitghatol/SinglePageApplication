/**
 * Created with JetBrains WebStorm.
 * User: rohit
 * Date: 7/20/12
 * Time: 9:15 PM
 * To change this template use File | Settings | File Templates.
 */

({
    appDir:"../",
    baseUrl:"js/",
    dir:"../../Backbone-Demo-Opt",

    paths:{

        'jquery':'libs/jquery/jquery-min',
        'underscore':'libs/underscore/underscore-min',
        'backbone':'libs/backbone/backbone-optamd3-min',
        'text':'libs/require/text'
    },

    modules:[
        {
            name:"main"
        }
    ]
})